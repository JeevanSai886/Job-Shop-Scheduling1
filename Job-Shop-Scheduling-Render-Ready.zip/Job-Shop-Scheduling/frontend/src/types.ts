export type Objective = 'makespan' | 'idle_time'
export type Engine = 'cp_sat' | 'pulp_bigm'
export type Status = 'optimal' | 'feasible' | 'no_solution' | 'infeasible' | 'model_invalid'
export interface Instance {
  instance_id: string; name: string; num_jobs: number; num_machines: number
  total_operations: number; job_labels: string[]; machine_labels: string[]
}
export interface Distribution { count: number; min: number | null; max: number | null; mean: number | null; std: number | null }
export interface Stats {
  num_jobs: number; num_machines: number; total_operations: number; total_processing_time: number; lower_bound: number
  processing_times: Distribution
  jobs: { job: number; label: string; operation_count: number; workload: number }[]
  machines: { machine: number; label: string; workload: number; processing_times: Distribution }[]
}
export interface Operation {
  job: number; operation: number; machine: number; job_label: string; machine_label: string
  duration: number; start: number; end: number
}
export interface Settings { objective: Objective; solver: Engine; time_limit_s: number }
export interface Result extends Settings {
  status: Status; proven_optimal: boolean; message: string; wall_time_s: number
  objective_value: number | null; best_bound: number | null; relative_gap: number | null
  makespan: number | null; total_idle_time: number | null; lower_bound: number; time_unit: number; big_m: number
  operations: Operation[]
  jobs: { job: number; label: string; completion: number }[]
  machines: { machine: number; label: string; workload: number; completion: number; idle_time: number; sequence: Operation[] }[]
}
export interface Sensitivity {
  objective: Objective; solver: Engine; baseline: Result; note: string
  scenarios: { delta: number; objective_change_pct: number | null; makespan_change_pct: number | null; result: Result }[]
}
