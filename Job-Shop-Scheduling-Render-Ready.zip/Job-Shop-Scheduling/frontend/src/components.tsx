import { useState } from 'react'
import { Clock3, Info, Layers3 } from 'lucide-react'
import type { ReactNode } from 'react'
import type { Operation, Result, Stats, Status } from './types'

export const fmt = (n: number | null | undefined, digits = 2) => n == null ? '—' : new Intl.NumberFormat('en', { maximumFractionDigits: digits }).format(n)
export const jobColor = (job: number) => `hsl(${(job * 137.508 + 153) % 360} 49% 44%)`
const statusLabels: Record<Status, string> = { optimal: 'Proven optimal', feasible: 'Feasible · unproven', no_solution: 'Time limit reached', infeasible: 'Infeasible', model_invalid: 'Invalid model' }
export function Badge({ status }: { status: Status }) { return <span className={`badge ${status}`}>{statusLabels[status]}</span> }
export function Panel({ title, eyebrow, aside, children, className = '' }: { title: string; eyebrow?: string; aside?: ReactNode; children: ReactNode; className?: string }) {
  return <section className={`panel ${className}`}><div className="panel-heading"><div>{eyebrow && <div className="eyebrow">{eyebrow}</div>}<h2>{title}</h2></div>{aside}</div>{children}</section>
}
export function Metric({ label, value, sub, icon, accent = false }: { label: string; value: string; sub: string; icon: ReactNode; accent?: boolean }) {
  return <div className={`metric ${accent ? 'metric-accent' : ''}`}><div className="metric-label">{label}{icon}</div><div className="metric-value">{value}</div><div className="metric-sub">{sub}</div></div>
}
export function Empty({ children }: { children: ReactNode }) { return <div className="empty"><div className="empty-icon"><Layers3 size={27} /></div>{children}</div> }

export function Workloads({ stats }: { stats: Stats }) {
  const max = Math.max(...stats.machines.map(machine => machine.workload))
  return <div className="workloads">{stats.machines.map(machine => <div className="workload" key={machine.machine}><span title={machine.label}>{machine.label}</span><div className="workload-track"><div style={{ width: `${max ? machine.workload / max * 100 : 0}%` }} /></div><strong>{fmt(machine.workload)}</strong></div>)}</div>
}

export function Gantt({ result }: { result: Result }) {
  const [selectedJob, setSelectedJob] = useState<number | null>(null)
  const [hover, setHover] = useState<Operation | null>(null)
  const [zoom, setZoom] = useState(100)
  const axis = 88, plotWidth = 920, right = 25, rowHeight = 58, top = 25, bottom = 38
  const width = axis + plotWidth + right, height = top + result.machines.length * rowHeight + bottom
  const horizon = result.makespan || 1
  const ticks = Array.from({ length: 7 }, (_, i) => horizon * i / 6)
  return <>
    <div className="gantt-toolbar"><div className="legend"><button className={selectedJob === null ? 'legend-all active' : 'legend-all'} onClick={() => setSelectedJob(null)}>All jobs</button>{result.jobs.map(job => <button key={job.job} className={selectedJob === job.job ? 'legend-job active' : 'legend-job'} onClick={() => setSelectedJob(selectedJob === job.job ? null : job.job)} aria-pressed={selectedJob === job.job}><i style={{ background: jobColor(job.job) }} />{job.label}</button>)}</div><label className="zoom">Zoom <input aria-label="Timeline zoom" type="range" min="100" max="300" value={zoom} onChange={e => setZoom(Number(e.target.value))} /></label></div>
    <div className="gantt-scroll"><svg className="gantt" width={`${zoom}%`} viewBox={`0 0 ${width} ${height}`} role="img" aria-label="Machine schedule. Focus or hover an operation for its timing details.">
      {result.machines.map((machine, i) => <g key={machine.machine}><rect x={axis} y={top + i * rowHeight} width={plotWidth} height={rowHeight} fill={i % 2 ? '#f6f8fa' : '#ffffff'} /><text x={axis - 15} y={top + i * rowHeight + rowHeight / 2 + 5} textAnchor="end" className="machine-label"><title>{machine.label}</title>{machine.label.length > 9 ? `${machine.label.slice(0, 8)}…` : machine.label}</text></g>)}
      {ticks.map(tick => <g key={tick}><line x1={axis + tick / horizon * plotWidth} x2={axis + tick / horizon * plotWidth} y1={top} y2={height - bottom} stroke="#e4e9ee" strokeDasharray="3 4" /><text x={axis + tick / horizon * plotWidth} y={height - 13} textAnchor="middle" className="axis-label">{fmt(tick, 1)}</text></g>)}
      {result.operations.map(op => {
        const x = axis + op.start / horizon * plotWidth, y = top + op.machine * rowHeight + 10, w = op.duration / horizon * plotWidth
        const label = `${op.job_label} · operation ${op.operation + 1} · ${op.machine_label} · start ${fmt(op.start)} · end ${fmt(op.end)} · duration ${fmt(op.duration)}`
        return <g key={`${op.job}-${op.operation}`} tabIndex={0} role="img" aria-label={label} className="gantt-operation" opacity={selectedJob === null || selectedJob === op.job ? 1 : 0.16} onMouseEnter={() => setHover(op)} onMouseLeave={() => setHover(null)} onFocus={() => setHover(op)} onBlur={() => setHover(null)}>
          <title>{label}</title><rect x={x + 0.5} y={y} width={Math.max(w - 1, 0.6)} height={rowHeight - 20} rx={4} fill={jobColor(op.job)} />
          {w > 28 && <text x={x + w / 2} y={y + (rowHeight - 20) / 2 + 4} textAnchor="middle" fill="white" fontSize={12} fontWeight={600} pointerEvents="none">{op.job_label.length * 7 < w - 8 ? op.job_label : `J${op.job + 1}`}</text>}
        </g>
      })}
    </svg></div>
    <div className="gantt-caption" aria-live="polite"><Info size={15} />{hover ? <span><strong>{hover.job_label} / Op {hover.operation + 1}</strong> on {hover.machine_label} · Start {fmt(hover.start)} · End {fmt(hover.end)} · Duration {fmt(hover.duration)}</span> : <span>Hover or focus an operation to inspect it. Select a job to follow its route.</span>}<span className="time-unit">Time units →</span></div>
  </>
}

export function ResultsTable({ result, view }: { result: Result; view: string }) {
  if (view === 'Jobs') return <div className="table-wrap"><table><thead><tr><th>Job</th><th>Operations</th><th>Completion time</th></tr></thead><tbody>{result.jobs.map(job => <tr key={job.job}><td><span className="job-tag" style={{ color: jobColor(job.job) }}>{job.label}</span></td><td>{result.operations.filter(op => op.job === job.job).length}</td><td>{fmt(job.completion)}</td></tr>)}</tbody></table></div>
  if (view === 'Sequences') return <div className="table-wrap"><table><thead><tr><th>Machine</th><th>Operation sequence</th><th>Completion</th><th>Idle time</th></tr></thead><tbody>{result.machines.map(machine => <tr key={machine.machine}><td>{machine.label}</td><td><div className="sequence">{machine.sequence.map(op => <span key={`${op.job}-${op.operation}`} style={{ borderColor: jobColor(op.job) }}>{op.job_label}.{op.operation + 1}</span>)}</div></td><td>{fmt(machine.completion)}</td><td>{fmt(machine.idle_time)}</td></tr>)}</tbody></table></div>
  return <div className="table-wrap operations-table"><table><thead><tr><th>Job</th><th>Operation</th><th>Machine</th><th>Duration</th><th>Start</th><th>End</th></tr></thead><tbody>{result.operations.map(op => <tr key={`${op.job}-${op.operation}`}><td><span className="job-tag" style={{ color: jobColor(op.job) }}>{op.job_label}</span></td><td>{op.operation + 1}</td><td>{op.machine_label}</td><td>{fmt(op.duration)}</td><td>{fmt(op.start)}</td><td>{fmt(op.end)}</td></tr>)}</tbody></table></div>
}

export function SolverFootnote({ result }: { result: Result }) {
  return <div className="solver-footnote"><span><Clock3 size={14} /> Solved in {fmt(result.wall_time_s)}s</span><span>Engine: {result.solver === 'cp_sat' ? 'CP-SAT' : 'CBC · Big-M'}</span><span>Objective: {result.objective === 'makespan' ? 'Makespan' : 'Total idle time'}</span><span>Best bound: {fmt(result.best_bound)}</span><span>Gap: {result.relative_gap === null ? 'Unavailable' : `${fmt(result.relative_gap * 100)}%`}</span></div>
}
